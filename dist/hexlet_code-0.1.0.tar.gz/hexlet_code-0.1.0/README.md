### Hexlet tests and linter status:
[![Actions Status](https://github.com/EugeneYv/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/EugeneYv/python-project-49/actions)
<a href="https://codeclimate.com/github/EugeneYv/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/495a0e4812de7ca8e3a0/maintainability" /></a>
